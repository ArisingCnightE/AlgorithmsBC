﻿using System;

namespace NaughtyAttributes
{
    public interface INaughtyAttribute
    {
    }
}
