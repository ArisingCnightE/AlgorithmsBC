﻿using System;

namespace NaughtyAttributes
{
    public class ValidatorAttribute : Attribute, INaughtyAttribute
    {
    }
}
